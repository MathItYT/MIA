"""
CLI tool for Loquendo TTS Director 7 on Linux
=============================================
Usage:
    python -m loquendo.cli "Texto a decir" -o salida.wav -v Jorge
    python -m loquendo.cli --batch guion.json -o audios/
"""
import argparse
import json
import sys
from pathlib import Path

from loquendo.api import LoquendoTTS


def main() -> None:
    parser = argparse.ArgumentParser(description="Loquendo TTS Director 7 Automation CLI for Linux")
    parser.add_argument("text", nargs="?", help="Text to synthesize with Director tags (e.g. '\\pause=500\\')")
    parser.add_argument("-o", "--output", default="output.wav", help="Output WAV file path or directory (for batch)")
    parser.add_argument("-v", "--voice", default="Jorge", choices=["Jorge", "Carlos", "Ludoviko"], help="Voice persona")
    parser.add_argument("-l", "--language", default="Spanish", help="Language code (Spanish, SpanishEs, etc.)")
    parser.add_argument("-r", "--sample-rate", type=int, default=44100, help="Output sample rate in Hz (default: 44100, studio quality)")
    parser.add_argument("--norm", action="store_true", help="Enable audio loudness normalization (default: disabled for pristine Director 7 GUI fidelity)")
    parser.add_argument("--batch", help="JSON file containing list of takes/scenes for batch synthesis")
    parser.add_argument("--prefix", default="take", help="Batch take prefix name")

    args = parser.parse_args()
    tts = LoquendoTTS(
        default_voice=args.voice,
        default_language=args.language,
        target_sample_rate=args.sample_rate,
        normalize_audio=args.norm,
    )

    if args.batch:
        batch_path = Path(args.batch)
        if not batch_path.exists():
            print(f"Error: Batch file not found: {batch_path}", file=sys.stderr)
            sys.exit(1)
        items = json.loads(batch_path.read_text(encoding="utf-8"))
        print(f"Synthesizing batch of {len(items)} items to {args.output}...")
        results = tts.synthesize_batch(items, output_dir=args.output, prefix=args.prefix)
        print(f"Successfully generated {len(results)} audio files with beats manifest.")
    elif args.text:
        res = tts.synthesize(text=args.text, output_file=args.output, voice=args.voice, language=args.language)
        print(f"Generated: {res.file_path}")
        print(f"Duration: {res.duration_seconds:.2f}s | Sample Rate: {res.sample_rate}Hz | Channels: {res.channels} | Voice: {res.voice}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
