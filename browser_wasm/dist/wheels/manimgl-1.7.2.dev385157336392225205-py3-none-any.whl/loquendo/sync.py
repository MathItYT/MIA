"""
ManimGL Audio Synchronization Context Manager (SyncLoquendo)
============================================================
Synchronizes Loquendo TTS 7 voice clips with visual animations in real Manim scenes.

Usage:
    class MyScene(Scene):
        def construct(self):
            with SyncLoquendo("Bienvenidos al curso de LLMs.", "takes/intro.wav") as sync:
                self.play(FadeIn(title), run_time=1.5)
                # If visual animations finish before audio, __exit__ waits the remaining audio time!
"""
from __future__ import annotations

import inspect
import os
import wave
from pathlib import Path
from typing import Any, Optional, Union

from loquendo.api import LoquendoTTS
from loquendo.builder import LoquendoText


class SyncLoquendo:
    """Context manager for synchronizing a Loquendo TTS 7 audio take with ManimGL scene animations.
    
    Can be called with:
        with SyncLoquendo("Texto", "audio.wav") as sync:
        with SyncLoquendo(self, "Texto", "audio.wav") as sync:
        with SyncLoquendo("Texto", "audio.wav", voice="Carlos", pad=0.2) as sync:
    """

    _default_tts: Optional[LoquendoTTS] = None

    def __init__(
        self,
        *args: Any,
        scene: Any = None,
        voice: str = "Jorge",
        language: str | None = None,
        pad: float = 0.0,
        force_regen: bool = False,
        postprocess: bool = False,
        tts: Optional[LoquendoTTS] = None,
        **kwargs: Any,
    ):
        self.pad = float(pad)
        self.voice = voice
        self.language = language
        self.force_regen = force_regen
        self.postprocess = postprocess
        self.tts = tts

        self.scene: Any = scene
        self.text: str = ""
        self.file_path: Path = Path("take.wav")

        self._parse_args(args)
        self._resolve_scene()
        self._ensure_audio_file()

        self._start_scene_time: float = 0.0

    def _is_scene_like(self, obj: Any) -> bool:
        """Check if an object has Scene-like methods (wait, add_sound, get_time, or play)."""
        if obj is None:
            return False
        return any(hasattr(obj, attr) for attr in ("wait", "add_sound", "get_time", "play"))

    def _parse_args(self, args: tuple[Any, ...]) -> None:
        """Parse arguments supporting both (scene, text, file) and (text, file)."""
        if len(args) == 0:
            raise ValueError("SyncLoquendo requires at least text and file_path.")
        elif len(args) == 1:
            self.text = str(args[0])
            self.file_path = Path("take.wav")
        elif len(args) == 2:
            first, second = args
            if self._is_scene_like(first):
                self.scene = first
                self.text = str(second)
                self.file_path = Path("take.wav")
            else:
                self.text = str(first)
                self.file_path = Path(str(second))
        elif len(args) >= 3:
            first, second, third = args[:3]
            if self._is_scene_like(first):
                self.scene = first
                self.text = str(second)
                self.file_path = Path(str(third))
            else:
                self.text = str(first)
                self.file_path = Path(str(second))

    def _resolve_scene(self) -> None:
        """Auto-detect the active Manim Scene from caller frames if not passed explicitly."""
        if self.scene is not None:
            return

        frame = inspect.currentframe()
        try:
            curr = frame.f_back if frame else None
            while curr:
                local_self = curr.f_locals.get("self")
                if self._is_scene_like(local_self):
                    self.scene = local_self
                    break
                curr = curr.f_back
        finally:
            del frame

    def _ensure_audio_file(self) -> None:
        """Verify if audio file exists; if not, synthesize it via Loquendo TTS 7 in Wine."""
        self.file_path = self.file_path.resolve()
        needs_generation = self.force_regen or (not self.file_path.exists()) or (self.file_path.stat().st_size == 0)

        if needs_generation:
            if not self.text:
                raise ValueError(f"Audio file '{self.file_path}' does not exist and no text was provided to synthesize it.")

            if self.tts is None:
                if SyncLoquendo._default_tts is None:
                    # Pristine native Loquendo 7 studio configuration (44.1 kHz linear PCM)
                    SyncLoquendo._default_tts = LoquendoTTS(normalize_audio=False, target_sample_rate=44100)
                self.tts = SyncLoquendo._default_tts

            self.file_path.parent.mkdir(parents=True, exist_ok=True)
            self.tts.synthesize(
                text=self.text,
                output_file=self.file_path,
                voice=self.voice,
                language=self.language,
                postprocess=self.postprocess,
            )

        # Read exact audio duration from native Loquendo 7 WAV header
        with wave.open(str(self.file_path), "rb") as wf:
            frames = wf.getnframes()
            rate = wf.getframerate()
            self.duration = float(frames) / float(rate) if rate > 0 else 0.0

    def __enter__(self) -> SyncLoquendo:
        """Start playing the audio and track scene timeline."""
        if self.scene is not None:
            if hasattr(self.scene, "get_time"):
                self._start_scene_time = self.scene.get_time()
            else:
                self._start_scene_time = getattr(self.scene, "time", 0.0)

            # Schedule audio playback in Manim scene
            if hasattr(self.scene, "add_sound"):
                self.scene.add_sound(str(self.file_path))
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Wait for the remaining audio duration if visual animations finished earlier."""
        if exc_type is not None:
            return

        if self.scene is None:
            return

        if hasattr(self.scene, "get_time"):
            current_time = self.scene.get_time()
        else:
            current_time = getattr(self.scene, "time", self._start_scene_time)

        elapsed = current_time - self._start_scene_time
        remaining = self.duration - elapsed

        # If visual animations ended before the audio clip finished, wait the remaining time
        if remaining > 0:
            if hasattr(self.scene, "wait"):
                self.scene.wait(remaining)

        # Apply any requested padding
        if self.pad > 0 and hasattr(self.scene, "wait"):
            self.scene.wait(self.pad)

    @property
    def elapsed_scene_time(self) -> float:
        """Get current elapsed scene time since entering the block."""
        if self.scene is None:
            return 0.0
        current_time = self.scene.get_time() if hasattr(self.scene, "get_time") else getattr(self.scene, "time", 0.0)
        return current_time - self._start_scene_time

    @property
    def remaining_audio_time(self) -> float:
        """Get remaining audio time based on current scene time."""
        return max(0.0, self.duration - self.elapsed_scene_time)
