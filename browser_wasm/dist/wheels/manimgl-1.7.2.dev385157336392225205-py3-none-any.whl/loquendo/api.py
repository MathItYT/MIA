"""
Loquendo TTS Director 7 Automation API for Linux (via Wine)
===========================================================
Automates high-fidelity audio generation with Loquendo TTS Director 7
using the native LTTS7 COM engine on Linux under Wine.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
import wave
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Sequence, Union

from loquendo.builder import LoquendoText

# Valid Director tag identifiers supported by Loquendo TTS 7
VALID_TAG_NAMES = {
    "pause", "speed", "pitch", "volume", "voice", "language",
    "item", "style", "spell", "say-as", "audio", "sub", "alias"
}

# Mapping of mathematical symbols to natural Spanish speech words
MATH_TO_SPANISH = [
    # Blackboard bold sets
    (r"\\mathbb\{R\}|ℝ", "los reales"),
    (r"\\mathbb\{Q\}|ℚ", "los racionales"),
    (r"\\mathbb\{N\}|ℕ", "los naturales"),
    (r"\\mathbb\{Z\}|ℤ", "los enteros"),
    (r"\\mathbb\{C\}|ℂ", "los complejos"),
    (r"\\mathbb\{E\}", "la esperanza"),
    # Greek letters
    (r"\\alpha|α", "alfa"),
    (r"\\beta|β", "beta"),
    (r"\\gamma|γ", "gamma"),
    (r"\\delta|δ", "delta"),
    (r"\\epsilon|\\varepsilon|ε|ϵ", "épsilon"),
    (r"\\theta|θ|ϑ", "theta"),
    (r"\\lambda|λ", "lambda"),
    (r"\\mu|μ", "mu"),
    (r"\\sigma|σ", "sigma"),
    (r"\\pi|π", "pi"),
    (r"\\omega|ω", "omega"),
    (r"\\phi|\\varphi|ϕ|φ", "fi"),
    (r"\\psi|ψ", "psi"),
    # Quantifiers & Logic
    (r"\\forall|∀", "para todo"),
    (r"\\exists|∃", "existe"),
    (r"\\neg|¬", "no"),
    (r"\\iff|⟺|⇔", "si y sólo si"),
    (r"\\implies|⟹|⇒", "implica"),
    (r"\\land|∧", " y "),
    (r"\\lor|∨", " o "),
    (r"\\bot|⊥", "contradicción"),
    (r"\\emptyset|∅", "conjunto vacío"),
    (r"\\in|∈", "en"),
    (r"\\notin|∉", "no pertenece a"),
    (r"\\subset|⊂", "subconjunto de"),
    (r"\\subseteq|⊆", "subconjunto o igual a"),
    (r"\\cup|∪", "unión"),
    (r"\\cap|∩", "intersección"),
    # Relations & Operators
    (r"\\leq|\\le|≤", "menor o igual que"),
    (r"\\geq|\\ge|≥", "mayor o igual que"),
    (r"\\neq|\\ne|≠", "distinto de"),
    (r"\\approx|≈", "aproximadamente igual a"),
    (r"\\equiv|≡", "equivalente a"),
    (r"\\times|×", "por"),
    (r"\\cdot|·", "por"),
    (r"\\infty|∞", "infinito"),
    (r"\\sum|∑", "suma"),
    (r"\\prod|∏", "producto"),
    (r"\\int|∫", "integral"),
    (r"\\nabla|∇", "nabla"),
    (r"\\partial|∂", "derivada parcial"),
    (r"\\sqrt\{2\}|\\sqrt2", "raíz de dos"),
    (r"\\sqrt", "raíz cuadrada"),
    # Typographic punctuation to standard Spanish punctuation
    (r"[—–]", ", "),
    (r"[“”«»]", '"'),
    (r"[‘’]", "'"),
    (r"…", "..."),
]


def sanitize_loquendo_text(text: str) -> str:
    """Sanitize and prepare text for Loquendo TTS 7.
    
    1. Preserves valid Loquendo tags (\\pause=500 , \\speed=110 , \\voice=Jorge ).
    2. Converts rare math symbols/LaTeX into natural, fluent Spanish words.
    3. Normalizes subscripts (x_i -> x sub i) and superscripts (x^2 -> x cuadrado).
    4. Strips any illegal/unsupported non-ASCII characters outside standard Spanish
       (áéíóúÁÉÍÓÚñÑüÜ¿?¡!.,:;-"'() ), ensuring Loquendo speaks with 100% natural fidelity.
    """
    # Step A: Convert math expressions and symbols to spoken Spanish
    # Subscript notation: x_i -> x sub i, L_{t} -> L sub t
    text = re.sub(r'([A-Za-z])_\{([A-Za-z0-9]+)\}', r'\1 sub \2', text)
    text = re.sub(r'([A-Za-z])_([A-Za-z0-9])', r'\1 sub \2', text)
    # Superscripts: x^2 -> x cuadrado, x^3 -> x cubo
    text = re.sub(r'([A-Za-z0-9])\^2', r'\1 cuadrado', text)
    text = re.sub(r'([A-Za-z0-9])\^3', r'\1 cubo', text)
    text = re.sub(r'([A-Za-z0-9])\^\{?([A-Za-z0-9]+)\}?', r'\1 a la \2', text)

    for pattern, replacement in MATH_TO_SPANISH:
        text = re.sub(pattern, replacement, text)

    # Step B: Tag extraction and trailing slash removal
    def replacer(match: re.Match) -> str:
        raw = match.group(0)
        inner = raw.strip('\\')
        tag_name = re.split(r"[=+\-]", inner)[0].lower()
        if tag_name in VALID_TAG_NAMES:
            return f"\x01{inner} "
        return f" {inner} "

    # Match \tag=val\ or \tag=val
    result = re.sub(r"\\[a-zA-Z0-9_=+%.-]+\\?", replacer, text)
    result = result.replace("\\", " ")
    result = result.replace("\x01", "\\")

    # Step C: Filter out rare symbols that cannot be spoken, keep only valid Spanish and punctuation
    # Allowed: ascii alphanumeric, Spanish vowels with tildes, ñ/Ñ, ü/Ü, ¿, ¡, standard punctuation, and tag characters \=+%
    allowed_chars = set(
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        "áéíóúÁÉÍÓÚñÑüÜ¿?¡!.,:;-\"'() \t\n\\=+%"
    )
    cleaned_chars = [c if c in allowed_chars else " " for c in result]
    result = "".join(cleaned_chars)

    # Clean whitespace and ensure valid tags followed directly by letters have a space delimiter
    result = re.sub(r"[ \t]+", " ", result).strip()
    result = re.sub(r"(\\[a-zA-Z]+=[a-zA-Z0-9_.-]+)(?=[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ¿¡])", r"\1 ", result)
    return result


@dataclass
class AudioResult:
    """Metadata for a synthesized audio clip."""
    file_path: str
    duration_seconds: float
    sample_rate: int
    channels: int
    voice: str
    text_content: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class LoquendoTTS:
    """Python API for Loquendo TTS Director 7 on Linux/Wine.
    
    Provides programmatic access to the full TTS Director engine,
    supporting voices (Jorge, Carlos, Ludoviko), languages (Spanish, SpanishEs, etc.),
    Director prosody tags, and YouTube-ready ffmpeg post-processing.
    """

    SUPPORTED_VOICES = ["Jorge", "Carlos", "Ludoviko"]
    SUPPORTED_LANGUAGES = [
        "Spanish",
        "SpanishEs",
        "SpanishMx",
        "SpanishAr",
        "SpanishCl",
        "SpanishAm",
        "Esperanto",
    ]
    # Native mother-tongue dialect for each Loquendo persona
    VOICE_DEFAULT_LANGUAGES = {
        "Jorge": "Spanish",      # Castilian Spanish (Spain)
        "Carlos": "SpanishAm",   # American Spanish (natural seseo, eliminates forced Castilian 'c' distortion)
        "Ludoviko": "Esperanto", # Esperanto
    }

    def __init__(
        self,
        default_voice: str = "Jorge",
        default_language: str = "Spanish",
        wine_prefix: Path | str | None = None,
        wine_cmd: str = "wine",
        target_sample_rate: int = 44100,
        channels: str = "Mono",
        normalize_audio: bool = False,
        target_lufs: float = -14.0,
    ):
        self.default_voice = default_voice
        self.default_language = default_language
        self.wine_cmd = wine_cmd
        self.wine_prefix = (
            Path(wine_prefix).resolve()
            if wine_prefix
            else Path(os.environ.get("WINEPREFIX", Path.home() / ".wine")).resolve()
        )
        self.drive_c = self.wine_prefix / "drive_c"
        self.target_sample_rate = target_sample_rate
        self.channels = channels
        self.normalize_audio = normalize_audio
        self.target_lufs = target_lufs

        self._verify_wine_environment()

    def _verify_wine_environment(self) -> None:
        """Verify Wine and Loquendo LTTS7 installation."""
        if not shutil.which(self.wine_cmd):
            raise RuntimeError(
                f"Wine binary '{self.wine_cmd}' not found on host. Please install Wine."
            )
        if not self.drive_c.exists():
            raise FileNotFoundError(
                f"Wine prefix drive_c not found at {self.drive_c}"
            )

        loq_bin = self.drive_c / "Program Files (x86)" / "Loquendo" / "LTTS7" / "bin"
        if not loq_bin.exists():
            raise FileNotFoundError(
                f"Loquendo LTTS7 bin directory not found at {loq_bin}"
            )

    def _to_wine_path(self, linux_path: Path) -> str:
        """Convert a Linux absolute path to a Wine Z: path."""
        abs_path = linux_path.resolve()
        return "Z:" + str(abs_path).replace("/", "\\")

    def _escape_vbs_string(self, text: str) -> str:
        """Escape text for VBScript string literal."""
        escaped = text.replace('"', '""')
        escaped = re.sub(r"[\r\n]+", " ", escaped)
        return escaped

    def _measure_wav_duration(self, wav_path: Path) -> tuple[float, int, int]:
        """Read duration, sample rate, and channel count from a WAV file."""
        with wave.open(str(wav_path), "rb") as wf:
            frames = wf.getnframes()
            rate = wf.getframerate()
            channels = wf.getnchannels()
            duration = frames / float(rate) if rate > 0 else 0.0
            return duration, rate, channels

    def _postprocess_audio(
        self,
        raw_wav: Path,
        output_wav: Path,
        sample_rate: int,
        normalize: bool,
        target_lufs: float,
    ) -> None:
        """Post-process audio with ffmpeg for YouTube broadcast loudness and sample rate."""
        ffmpeg_bin = shutil.which("ffmpeg")
        if not ffmpeg_bin:
            shutil.copy2(raw_wav, output_wav)
            return

        cmd = [ffmpeg_bin, "-y", "-i", str(raw_wav)]

        if normalize:
            cmd.extend([
                "-af",
                f"loudnorm=I={target_lufs}:TP=-1.5:LRA=7",
                "-ar",
                str(sample_rate),
                "-c:a",
                "pcm_s16le",
            ])
        else:
            cmd.extend([
                "-ar",
                str(sample_rate),
                "-c:a",
                "pcm_s16le",
            ])

        cmd.append(str(output_wav))

        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        if result.returncode != 0:
            shutil.copy2(raw_wav, output_wav)

    def synthesize(
        self,
        text: Union[str, LoquendoText],
        output_file: Union[str, Path],
        voice: str | None = None,
        language: str | None = None,
        postprocess: bool | None = None,
        sample_rate: int | None = None,
        channels: str | None = None,
    ) -> AudioResult:
        """Synthesize text into a WAV file using Loquendo TTS Director 7.
        
        Args:
            text: String with Director tags (e.g. '\\pause=400 ') or a LoquendoText builder.
            output_file: Destination path for the generated .wav file.
            voice: Voice persona ('Jorge', 'Carlos', 'Ludoviko'). Defaults to self.default_voice.
            language: Language variant ('Spanish', 'SpanishEs', etc.). Defaults to self.default_language.
            postprocess: Whether to apply ffmpeg normalization and resampling (default: False for pristine GUI quality).
            sample_rate: Target sample rate in Hz (e.g. 44100, 48000, 32000). Defaults to self.target_sample_rate.
            channels: Audio channels ('Mono' or 'Stereo'). Defaults to self.channels.
        """
        voice = voice or self.default_voice
        if language is None or (language == "Spanish" and voice == "Carlos"):
            language = self.VOICE_DEFAULT_LANGUAGES.get(voice, self.default_language)
        postprocess = self.normalize_audio if postprocess is None else postprocess
        target_sr = sample_rate or self.target_sample_rate
        audio_channels = channels or self.channels

        raw_str = str(text).strip()
        if not raw_str:
            raise ValueError("Text to synthesize cannot be empty.")

        # Clean tags and replace math symbols with Spanish speech
        clean_text = sanitize_loquendo_text(raw_str)

        out_path = Path(output_file).resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_dir_path = Path(tmp_dir)
            raw_wav_path = tmp_dir_path / "raw_tts.wav"
            vbs_script_path = tmp_dir_path / "generate.vbs"

            raw_wine_path = self._to_wine_path(raw_wav_path)
            escaped_text = self._escape_vbs_string(clean_text)

            vbs_content = f"""' Loquendo TTS Director 7 High-Fidelity Automation Script
Dim objLTTS
Set objLTTS = CreateObject("LTTS7.LoqTTSCtrl.1")
objLTTS.Voice = "{voice}"
objLTTS.Language = "{language}"
objLTTS.Frequency = {target_sr}
objLTTS.AudioChannels = "{audio_channels}"
objLTTS.Record "{escaped_text}", "{raw_wine_path}"
Set objLTTS = Nothing
"""
            # CRITICAL: Encode strictly as Windows CP1252 so Wine/cscript reads ñ, tildes, ¿, ¡ natively
            vbs_script_path.write_bytes(vbs_content.encode("cp1252", errors="replace"))
            wine_script_path = self._to_wine_path(vbs_script_path)

            cscript_exe = "C:\\windows\\syswow64\\cscript.exe"
            loq_bin_dir = self.drive_c / "Program Files (x86)" / "Loquendo" / "LTTS7" / "bin"

            env = dict(os.environ)
            env["WINEDEBUG"] = "-all"

            wine_proc = subprocess.run(
                [self.wine_cmd, cscript_exe, wine_script_path],
                cwd=str(loq_bin_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
            )

            if wine_proc.returncode != 0 or not raw_wav_path.exists():
                err_msg = (
                    f"Loquendo synthesis failed with code {wine_proc.returncode}.\n"
                    f"Stderr: {wine_proc.stderr}\nStdout: {wine_proc.stdout}"
                )
                raise RuntimeError(err_msg)

            if postprocess:
                self._postprocess_audio(
                    raw_wav=raw_wav_path,
                    output_wav=out_path,
                    sample_rate=target_sr,
                    normalize=True,
                    target_lufs=self.target_lufs,
                )
            else:
                shutil.copy2(raw_wav_path, out_path)

        duration, final_sr, channels = self._measure_wav_duration(out_path)

        return AudioResult(
            file_path=str(out_path),
            duration_seconds=duration,
            sample_rate=final_sr,
            channels=channels,
            voice=voice,
            text_content=clean_text,
        )

    def synthesize_batch(
        self,
        items: Sequence[tuple[str, Union[str, LoquendoText]] | dict[str, Any]],
        output_dir: Union[str, Path],
        prefix: str = "take",
        generate_manifest: bool = True,
    ) -> list[AudioResult]:
        """Synthesize a series of audio takes and generate an alignment manifest (.beats.json)."""
        out_dir = Path(output_dir).resolve()
        out_dir.mkdir(parents=True, exist_ok=True)

        results: list[AudioResult] = []
        manifest_entries: list[dict[str, Any]] = []
        cumulative_time = 0.0

        for idx, item in enumerate(items):
            if isinstance(item, tuple):
                take_id, content = item
                voice = self.default_voice
            elif isinstance(item, dict):
                take_id = item.get("id", f"{prefix}_{idx:03d}")
                content = item["text"]
                voice = item.get("voice", self.default_voice)
            else:
                raise TypeError(f"Unsupported item format: {type(item)}")

            wav_file = out_dir / f"{take_id}.wav"
            res = self.synthesize(text=content, output_file=wav_file, voice=voice)
            results.append(res)

            manifest_entries.append({
                "id": take_id,
                "file": wav_file.name,
                "voice": res.voice,
                "start_time": round(cumulative_time, 3),
                "duration": round(res.duration_seconds, 3),
                "end_time": round(cumulative_time + res.duration_seconds, 3),
                "text": res.text_content,
            })
            cumulative_time += res.duration_seconds

        if generate_manifest:
            manifest_path = out_dir / f"{prefix}.beats.json"
            manifest_data = {
                "total_duration": round(cumulative_time, 3),
                "total_takes": len(results),
                "takes": manifest_entries,
            }
            manifest_path.write_text(json.dumps(manifest_data, indent=2, ensure_ascii=False), encoding="utf-8")

        return results
