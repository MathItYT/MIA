"""
Loquendo TTS Director 7 Automation Package
===========================================
"""
from loquendo.api import AudioResult, LoquendoTTS
from loquendo.builder import LoquendoText
from loquendo.sync import SyncLoquendo

__all__ = ["LoquendoTTS", "LoquendoText", "AudioResult", "SyncLoquendo"]
