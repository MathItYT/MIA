"""
Loquendo TTS Director 7 Tag Builder
===================================
Helper utility to construct Loquendo Director escape tags cleanly in Python.

Loquendo Director syntax requires an initial backslash "\\" and a final space
as delimiter (e.g. "\\pause=500 "). Trailing backslashes must NEVER be used,
as Loquendo will pronounce them as "barra invertida".
"""
from __future__ import annotations
from typing import Self


class LoquendoText:
    """Builder for Loquendo TTS Director 7 marked-up strings.
    
    Supports Director tags:
    - \\pause=ms : Silence for specified milliseconds (followed by space).
    - \\speed=val or \\speed+perc% : Speech rate.
    - \\pitch=val or \\pitch+perc%t : Voice pitch.
    - \\volume=val : Volume level.
    - \\voice=VoiceName : Dynamic speaker switch (e.g. Jorge, Carlos).
    """

    def __init__(self, initial_text: str = ""):
        self._parts: list[str] = []
        if initial_text:
            self._parts.append(initial_text)

    def say(self, text: str) -> Self:
        """Add speech text."""
        self._parts.append(text)
        return self

    def pause(self, milliseconds: int = 500) -> Self:
        """Insert a silence pause in milliseconds (followed by delimiter space)."""
        self._parts.append(f"\\pause={int(milliseconds)} ")
        return self

    def speed(self, rate_percentage: int) -> Self:
        """Set absolute or relative speed (e.g., 100 for normal, 85 for slow/measured, 120 for brisk)."""
        self._parts.append(f"\\speed={int(rate_percentage)} ")
        return self

    def speed_delta(self, delta_percentage: int) -> Self:
        """Modify speed by relative percentage (e.g., +15 or -10)."""
        sign = "+" if delta_percentage >= 0 else ""
        self._parts.append(f"\\speed{sign}{int(delta_percentage)}% ")
        return self

    def pitch(self, pitch_val: int) -> Self:
        """Set voice pitch (default ~100)."""
        self._parts.append(f"\\pitch={int(pitch_val)} ")
        return self

    def pitch_delta(self, delta_percentage: int) -> Self:
        """Modify pitch by relative tone percentage."""
        sign = "+" if delta_percentage >= 0 else ""
        self._parts.append(f"\\pitch{sign}{int(delta_percentage)}%t ")
        return self

    def volume(self, vol_percentage: int) -> Self:
        """Set volume percentage (default 100)."""
        self._parts.append(f"\\volume={int(vol_percentage)} ")
        return self

    def voice(self, voice_name: str) -> Self:
        """Switch voice character (e.g., 'Jorge', 'Carlos')."""
        self._parts.append(f"\\voice={voice_name} ")
        return self

    def emphasize(self, text: str, pitch_rise: int = 15, speed_drop: int = -10) -> Self:
        """Emphasize a mathematical keyword or crucial theorem statement."""
        self.pitch_delta(pitch_rise)
        self.speed_delta(speed_drop)
        self.say(text)
        self.pitch_delta(-pitch_rise)
        self.speed_delta(-speed_drop)
        return self

    def build(self) -> str:
        """Return the combined string with properly formatted Director control tags."""
        result = " ".join(p.strip() for p in self._parts if p.strip())
        # Ensure tags have trailing space
        import re
        result = re.sub(r"(\\[a-zA-Z0-9_=+%.-]+)(?=[^\s])", r"\1 ", result)
        return result

    def __str__(self) -> str:
        return self.build()
